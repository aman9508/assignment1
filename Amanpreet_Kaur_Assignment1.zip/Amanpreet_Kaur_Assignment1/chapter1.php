//Amanpreet kaur
//8622722
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php
    $base=5;
    $height=10;
    $area=0.5*($base*$height);
    $area= number_format($area,2);
    echo "The area of the triangle is ".$area.'</p>';
    define('MY_NAME','AMANPREET KAUR');
    echo '<p>My First name is:<strong>'.strtoupper(MY_NAME).'</strong></p>';
?>
</body>
</html>